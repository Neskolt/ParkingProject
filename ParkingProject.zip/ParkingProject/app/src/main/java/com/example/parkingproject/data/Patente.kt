package com.example.parkingproject.data

data class Patente (
    val patente: String,
    val horaIngreso: String
)
